#include "stm32f10x.h"
void adc_init();
uint16_t Get_adc(uint8_t ch);
uint16_t Get_ADC_V(uint8_t ch , uint8_t times);
