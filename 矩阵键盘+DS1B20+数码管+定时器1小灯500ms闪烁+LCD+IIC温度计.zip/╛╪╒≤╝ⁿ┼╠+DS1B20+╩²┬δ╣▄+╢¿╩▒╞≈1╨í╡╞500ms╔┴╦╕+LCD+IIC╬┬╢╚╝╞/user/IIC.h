unsigned char SendStr(unsigned char sla,unsigned char suba,unsigned char *s,unsigned char n);
unsigned int RcvStr(unsigned char x,unsigned char y);
