/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include <stdio.h>
#include "main.h"
#include "delay.h"
#include "DMA.h"
#include "TIMx.h"
#include "GPIOx.h"
#include "NVIC.h"
#include "USARTx.h"
#include "ds18b20.h"
#include "LCD12864.h"
#include "IIC.h"
#include "adc.h"
/* �궨�� ------------------------------------------------------------------*/
#define uchar unsigned char
#define uint unsigned int
#define LED1 PEout( 0 )
#define LED2 PEout( 1 )
#define LED3 PEout( 2 )
#define LED4 PEout( 3 )
#define LED5 PEout( 4 )
#define LED6 PEout( 5 )
#define LED7 PEout( 6 )
#define LED8 PEout( 7 )
#define LOW 0
#define HIGH 1


/* �������� ------------------------------------------------------------------*/
u8 Delay_1s_Finishflag = 0;
u8 KeyTrg = 0; 	//��������
u8 KeyCont = 0; //��������

uint32_t hhh=0;
unsigned char display_code[]={	0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f,0x80,0x40,0x00,
																0xbf,0x86,0xdb,0xcf,0xe6,0xed,0xfd,0x87,0xff,0xef,0x39 };
unsigned char display_cache[]={32,32,32,32,32};
unsigned char display_cache_LCD[]={12,12,12,12,12};
u8 Motor_Arrived = 0; 		//���  �����ʶ
/* �������� ------------------------------------------------------------------*/
void RTC_configuration( void );
void RCC_Configuration( void );
void KeyRead( void );

void Delay_Ms( u16 time );
void delay_1s( uint time );
void delay1(uint32_t ntime);
void SysTick_Handler(void);
unsigned char key_value(void);
void display_led(unsigned char *p);

void TIM1_UP_IRQHandler( void )
{
	if (TIM_GetITStatus(TIM1, TIM_IT_Update) != RESET)
		PEout( 0 )	=~ PEout( 0 );
	display_led(display_cache);
	TIM_ClearITPendingBit(TIM1,TIM_IT_Update);
}
//================================== MAIN =======================================
int main( void )
{
	
	RCC_Configuration();
//	RTC_configuration();
	GPIO_Configuration();
	NVIC_Configuration();
	EXTI_Configuration();
	Tim1_Init(7199,20);
	adc_init();
//	if(SysTick_Config(SystemCoreClock/1000))
//	{
//		while(1);
//	}
	
	PSB_0;
	CS_1;
	lcd_init();//LCD12864��ʼ��
	lcd_clear();//����
	lcd_wstr(1, 0, "18B20:");//�ַ���ʾ
	lcd_wstr(2, 0, "LM75:");//�ַ���ʾ
	lcd_wstr(3, 0, "V:");//�ַ���
	u8 key;
	unsigned char ttemp=0;
	unsigned int temp=117;
	unsigned int tempp=117;
  while ( 1 )
  {
		delay_ms(200);
		ttemp|= read_temp(); 
		display_cache_LCD[0]=ttemp/10+48;
		display_cache_LCD[1]=ttemp%10+48;
		display_cache_LCD[2]=45;
		display_cache_LCD[3]=45;
		display_cache_LCD[4]=45;
		lcd_wstr(1, 3, display_cache_LCD);
		delay_ms(200);
		
		tempp=RcvStr(0x90,0x00);
		tempp=tempp>>5;
		tempp=tempp*0.125*100;

		display_cache_LCD[0]=display_cache[0]=tempp/1000+48;
		display_cache_LCD[1]=tempp/100%10+48;
		display_cache_LCD[2]=46;
		display_cache_LCD[3]=tempp/10%10+48;
		display_cache_LCD[4]=tempp%10+48;
		lcd_wstr(2, 3, display_cache_LCD);
		delay_ms(200);

		temp=Get_ADC_V(ADC_Channel_2,10)*0.0008*1000;
		display_cache_LCD[0]=display_cache[0]=temp/1000+48;
		display_cache_LCD[1]=temp/100%10+48;
		display_cache_LCD[2]=46;
		display_cache_LCD[3]=temp/10%10+48;
		display_cache_LCD[4]=temp%10+48;
		lcd_wstr(3, 3, display_cache_LCD);
		
		
		if(temp&0x01)
			PEout(0)=1;
		else
			PEout(0)=0;
		if(temp&0x02)
			PEout(1)=1;
		else
			PEout(1)=0;
		if(temp&0x04)
			PEout(2)=1;
		else
			PEout(2)=0;
		if(temp&0x08)
			PEout(3)=1;
		else
			PEout(3)=0;
		if(temp&0x10)
			PEout(4)=1;
		else
			PEout(4)=0;
		if(temp&0x20)
			PEout(5)=1;
		else
			PEout(5)=0;
		if(temp&0x40)
			PEout(6)=1;
		else
			PEout(6)=0;
		if(temp&0x80)
			PEout(7)=1;
		else
			PEout(7)=0;
		
		
		
		if((temp/1000)==0)
			display_cache[0]=12;
		else
			display_cache[0]=temp/1000;
		
		if(((temp/100%10)==0)&&((temp/1000)==0))
			display_cache[1]=12;
		else
			display_cache[1]=temp/100%10+13;
		
		if((temp/100%10==0)&&(temp/10%10==0)&&((temp/1000)==0))
			display_cache[2]=12;
		else
			display_cache[2]=temp/10%10;

		display_cache[3]=temp%10;
//		
//		
//		if((temp/100%10)==0)
//			display_cache_LCD[0]=32;
//		else
//			display_cache_LCD[0]=temp/100%10+48;
//		
//		if((temp/100%10==0)&&(temp/10%10==0))
//			display_cache[1]=32;
//		else
//			display_cache_LCD[1]=temp/10%10+48;

//		display_cache_LCD[2]=temp%10+48;
//		
//		display_cache_LCD[3]='C';
//		display_cache_LCD[4]='\0';
//		lcd_wstr(1, 5,display_cache_LCD);//�ַ���ʾ
		
		
		
//		if(init_ds18b20()==0)
//			LED8=1;
//		else
//			LED8=0;
			
		
//		key = key_value( );
//		if(key == 0xff )
//			key = key;
//		if(key==0x00)	
//			LED1 = 1;
//		else
//			LED1 = 0;
//		if(key==0x05)	
//			LED2 = 1;
//		else 
//			LED2 = 0;
//		if(key==0x0A)	
//			LED3 = 1;
//		else 
//			LED3 = 0;
//		if(key==0x0F)	
//			LED4 = 1;
//		else
//			LED4 = 0;
//		
//		if(PCin(8)==LOW)	
//			LED5 = 1;
//		else
//			LED5 = 0;
//		if(PCin(9)==LOW)	
//			LED6 = 1;
//		else
//			LED6 = 0;
//		if(PCin(10)==LOW)	
//			LED7 = 1;
//		else
//			LED7 = 0;
//		if(PCin(11)==LOW)	
//			LED8 = 1;
//		else
//			LED8 = 0;
		
  }
}
void display_led(unsigned char *p)
{
	static unsigned char disnum=0;
	
	switch (disnum)
	{
		case 0 : 	PBout(11)=1;
							PBout(13)=1;
							PBout(15)=0;
			break;
		case 1 : 	PBout(11)=0;
							PBout(13)=1;
							PBout(15)=0;
			break;
		case 2 : 	PBout(11)=1;
							PBout(13)=0;
							PBout(15)=0;
			break;
		case 3 : 	PBout(11)=0;
							PBout(13)=0;
							PBout(15)=0;
			break;
		default :
			break;
	}
		PBout(0)=display_code[p[disnum]]&0x01;
		PBout(2)=(display_code[p[disnum]]&0x02)>>1;
		PBout(1)=(display_code[p[disnum]]&0x04)>>2;
		PBout(9)=(display_code[p[disnum]]&0x08)>>3;
		PBout(7)=(display_code[p[disnum]]&0x10)>>4;
		PBout(10)=(display_code[p[disnum]]&0x20)>>5;
		PBout(12)=(display_code[p[disnum]]&0x40)>>6;
		PBout(5)=(display_code[p[disnum]]&0x80)>>7;
		
//		if(PAin(12)==0)
//			LED8=1;
//		else
//			LED8=0;
		
			disnum++;
		if(disnum==4)
			disnum=0;
		//DBUG_LED
//		if(PBin(0)==1)
//			LED1 = 1;
//		else
//			LED1 = 0;	
//		if(PBin(2)==1)
//			LED2 = 1;
//		else
//			LED2 = 0;	
//		if(PBin(1)==1)
//			LED3 = 1;
//		else
//			LED3 = 0;	
//		if(PBin(9)==1)
//			LED4 = 1;
//		else
//			LED4 = 0;	
//		if(PBin(7)==1)
//			LED5 = 1;
//		else
//			LED5 = 0;	
//		if(PBin(10)==1)
//			LED6 = 1;
//		else
//			LED6 = 0;	
//		if(PBin(12)==1)
//			LED7 = 1;
//		else
//			LED7 = 0;	
//		if(PBin(5)==1)
//			LED8 = 1;
//		else
//			LED8 = 0;	
}

unsigned char key_value(void)
{
	unsigned char ret_value=0xFF;
	unsigned char for_num=8;
	
	for(;for_num<12;for_num++)
	{
		PCout(for_num)=LOW;
		if((PCin(0)==LOW)||(PCin(1)==LOW)||(PCin(2)==LOW)||(PCin(3)==LOW))
		{	
			
			switch(for_num)
			{
				case 8 : 	if(PCin(0)==LOW)	ret_value = 0x00;
									else if(PCin(1)==LOW)	ret_value = 0x01;
									else if(PCin(2)==LOW)	ret_value = 0x02;
									else if(PCin(3)==LOW)	ret_value = 0x03;
									
				break;
				case 9 :  if(PCin(0)==LOW)	ret_value = 0x04;
									else if(PCin(1)==LOW)	ret_value = 0x05;
									else if(PCin(2)==LOW)	ret_value = 0x06;
									else if(PCin(3)==LOW)	ret_value = 0x07;
				break;	
				case 10 : if(PCin(0)==LOW)	ret_value = 0x08;
									else if(PCin(1)==LOW)	ret_value = 0x09;
									else if(PCin(2)==LOW)	ret_value = 0x0A;
									else if(PCin(3)==LOW)	ret_value = 0x0B;
				break;	
				case 11 : if(PCin(0)==LOW)	ret_value = 0x0C;
									else if(PCin(1)==LOW)	ret_value = 0x0D;
									else if(PCin(2)==LOW)	ret_value = 0x0E;
									else if(PCin(3)==LOW)	ret_value = 0x0F;
				break;
				default :break;
			}
		}
		PCout(for_num)=HIGH;
	}
	return ret_value;
	
}





//==========================�ӳ������=================================
/**
  * @brief  ʱ������
  * @param  None
  * @retval None
  */
//�ⲿ����Ϊ8M, PLLCLK=SYSCLK=72M, HCLK=72M, P2CLK=72M, P1CLK=36M, ADCCLK=36M, USBCLK=48M, TIMCLK=72M
void RCC_Configuration( void )
{
	ErrorStatus HSEStartUpStatus; //�������״̬ö�ٱ���ERROR, SUCCESS 
	
	RCC_DeInit(); //RCC�Ĵ�����������ΪĬ��ֵ
	RCC_HSEConfig( RCC_HSE_ON ); //���ⲿ����ʱ�Ӿ���
	HSEStartUpStatus = RCC_WaitForHSEStartUp();//�ȴ��ⲿ����ʱ�ӹ���
	if(HSEStartUpStatus == SUCCESS)
	{

		RCC_HCLKConfig( RCC_SYSCLK_Div1 ); //����AHB����Ƶ, HCLK = SYSCLK
		RCC_PCLK2Config( RCC_HCLK_Div1 ); //����APB2����Ƶ, P2CLK = HCLK
		RCC_PCLK1Config( RCC_HCLK_Div2 ); //����APB1Ϊ2��Ƶ,P1CLK = HCLK / 2
		
		FLASH_SetLatency( FLASH_Latency_2 ); //����FLASH������ʱ	   
		FLASH_PrefetchBufferCmd( FLASH_PrefetchBuffer_Enable ); //����Ԥȡָ����
		
		RCC_PLLConfig( RCC_PLLSource_HSE_Div1, RCC_PLLMul_9 ); //����PLLʱ��,�ⲿʱ�Ӳ���Ƶ,ΪHSE��9��Ƶ,8MhZ * 9 = 72MHZ
		RCC_PLLCmd(ENABLE); //ʹ��PLL
		
		while(RCC_GetFlagStatus( RCC_FLAG_PLLRDY) == RESET ); //�ȴ�PLL׼������
		RCC_SYSCLKConfig( RCC_SYSCLKSource_PLLCLK ); //����PLLΪϵͳʱ��Դ
		while( RCC_GetSYSCLKSource() != 0x08 ); //�ж�PLL�Ƿ�Ϊϵͳʱ��Դ
		
	}
}

/**
  * @brief  RTCʵʱʱ������
  * @param  None
  * @retval None
  */
void RTC_configuration( void )
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_BKP|RCC_APB1Periph_PWR,ENABLE);
	PWR_BackupAccessCmd(ENABLE);
	BKP_DeInit();
	RCC_LSEConfig(RCC_LSE_ON); 
	while(RCC_GetFlagStatus(RCC_FLAG_LSERDY)==RESET);
	RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE);
	RCC_RTCCLKCmd(ENABLE);
	RTC_WaitForSynchro();
	RTC_WaitForLastTask();

	RTC_WaitForLastTask();
	RTC_SetPrescaler( 32767 );
	RTC_WaitForLastTask(); 
	PWR_BackupAccessCmd(DISABLE);
}

/**
  * @brief  STM32���尴�� ��ѯ����
  * @param  None
  * @retval None
  */	
void KeyRead( void )
{
	u8 ReadKey_Data; //��ȡ������������
	ReadKey_Data = GPIOC -> IDR ^ 0x0f;
	KeyTrg = ReadKey_Data & ( ReadKey_Data ^ KeyCont );
	KeyCont = ReadKey_Data;
}	

/**
  * @brief  ������ʱ����
  * @param  None
  * @retval None
  */
void Delay_Ms( u16 time ) //��ʱ1ms����
{ 
	u16 i,j;
	for( i = 0; i < time; i++ )
  		for( j = 10; j > 0; j-- );
}

/**
  * @brief  TIM4 ��ȷ��ʱ
  * @param  None
  * @retval None
  */
//void delay_1s( uint time ) //��ʱ1s����
//{ 
//	uint i;
//	for( i = 0; i < time; i++ )
//	{
//		TIM_Cmd( TIM4, ENABLE ); //������ʱ��TIM4
//		while( !Delay_1s_Finishflag );
//		Delay_1s_Finishflag = 0;
//	}
//}
//void delay1(uint32_t ntime)
//{
//	hhh=ntime;
//	while(hhh != 0);
//}
//void SysTick_Handler(void)
//{
//	if(hhh!=0x00)
//	{ 
//		hhh--;
//	}
//}
