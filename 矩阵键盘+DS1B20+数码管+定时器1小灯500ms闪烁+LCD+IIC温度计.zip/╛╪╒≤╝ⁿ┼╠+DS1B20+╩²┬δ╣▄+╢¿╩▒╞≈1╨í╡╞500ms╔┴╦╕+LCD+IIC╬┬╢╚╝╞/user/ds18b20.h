
#define uchar unsigned char
unsigned char init_ds18b20(void);	
unsigned char read_temp(void);
//unsigned char rd_temperature(void);  //; ;
